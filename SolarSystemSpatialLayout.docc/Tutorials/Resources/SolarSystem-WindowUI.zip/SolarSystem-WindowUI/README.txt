SolarSystem-WindowUI
====================

이 폴더에는 7챕터(Spatial Layout으로 창 다시 만들기)를 시작하기 전에 필요한,
"단순 정보"만 담은 창 UI 코드가 들어 있습니다. 각 파일이 어떤 개념을
가르치는 게 아니라 그냥 화면에 보여줄 문구/버튼을 담고 있을 뿐이라
튜토리얼 스텝으로 만들지 않고 파일 그대로 제공합니다.

넣는 방법
1. Model/Module.swift 를 프로젝트의 Model 폴더로 복사합니다.
2. Solar System/ 안의 5개 파일(SwitchWindows.swift, SolarCard.swift,
   SolarSystemControls.swift, ToggleImmersiveSpaceButton.swift,
   SolarSystemModule.swift)을 프로젝트의 Solar System 폴더로 복사합니다.
3. Resources/Assets.xcassets 안의 SolarSystem.imageset,
   SolarBackground.imageset 두 개를 프로젝트의 Assets.xcassets에 추가합니다.
4. SolarSystemApp.swift에서 WindowGroup의 콘텐츠를 ContentView() 대신
   SwitchWindows()로 바꿉니다.

이 상태로 빌드하면 6챕터까지 만든 몰입 공간은 그대로 두고, 창만
SwitchWindows/SolarCard 기반으로 바뀝니다. 이제 7챕터에서 이 SwitchWindows.swift와
SolarCard.swift를 SpatialContainer/depthAlignment로 바꿔봅니다.
